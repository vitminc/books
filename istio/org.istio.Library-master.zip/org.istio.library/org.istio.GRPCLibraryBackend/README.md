## gRPC Library backend

docker build -f Dockerfile -t vitminc/sentiment-analysis-frontend .